const express = require('express');
const router = express.Router();
const { pool: db } = require('../config/db');
const { verifyToken, verifyAdmin } = require('../middleware/auth');

// GET all vehicles (with optional filters)
router.get('/', async (req, res) => {
  try {
    const { type, location, available, search } = req.query;
    let query = 'SELECT * FROM vehicles WHERE 1=1';
    const params = [];
    if (type)      { query += ' AND type = ?';                params.push(type); }
    if (location)  { query += ' AND location LIKE ?';         params.push('%' + location + '%'); }
    if (available === 'true') { query += ' AND availability = 1'; }
    if (search)    { query += ' AND (name LIKE ? OR brand LIKE ?)'; params.push('%' + search + '%', '%' + search + '%'); }
    query += ' ORDER BY created_at DESC';
    const [rows] = await db.query(query, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// GET single vehicle
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM vehicles WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ message: 'Vehicle not found.' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});

// POST add vehicle — admin only
router.post('/', verifyAdmin, async (req, res) => {
  try {
    const { name, type, brand, fuel_type, seats, price_per_day, image_url, location, description } = req.body;
    if (!name || !type || !price_per_day)
      return res.status(400).json({ message: 'name, type, and price_per_day are required.' });

    const [result] = await db.query(
      'INSERT INTO vehicles (name, type, brand, fuel_type, seats, price_per_day, image_url, location, description) VALUES (?,?,?,?,?,?,?,?,?)',
      [name, type, brand || null, fuel_type || 'petrol', seats || 5, price_per_day, image_url || null, location || null, description || null]
    );
    const [newV] = await db.query('SELECT * FROM vehicles WHERE id = ?', [result.insertId]);
    res.status(201).json({ message: 'Vehicle added.', vehicle: newV[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// PUT update vehicle — admin only
router.put('/:id', verifyAdmin, async (req, res) => {
  try {
    const { name, type, brand, fuel_type, seats, price_per_day, image_url, location, availability, description } = req.body;
    await db.query(
      'UPDATE vehicles SET name=?,type=?,brand=?,fuel_type=?,seats=?,price_per_day=?,image_url=?,location=?,availability=?,description=? WHERE id=?',
      [name, type, brand, fuel_type, seats, price_per_day, image_url, location, availability ? 1 : 0, description, req.params.id]
    );
    res.json({ message: 'Vehicle updated.' });
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});

// DELETE vehicle — admin only
router.delete('/:id', verifyAdmin, async (req, res) => {
  try {
    await db.query('DELETE FROM vehicles WHERE id = ?', [req.params.id]);
    res.json({ message: 'Vehicle deleted.' });
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;
