const API = 'http://localhost:5000/api';

// ── AUTH ──────────────────────────────────────────────────────
const Auth = {
  getToken: () => localStorage.getItem('rr_token'),
  getUser:  () => { try { return JSON.parse(localStorage.getItem('rr_user')); } catch { return null; } },
  isLoggedIn: () => !!localStorage.getItem('rr_token'),
  isAdmin:    () => { const u = Auth.getUser(); return u && u.role === 'admin'; },
  save: (token, user) => {
    localStorage.setItem('rr_token', token);
    localStorage.setItem('rr_user', JSON.stringify(user));
  },
  clear: () => {
    localStorage.removeItem('rr_token');
    localStorage.removeItem('rr_user');
  },
  logout(base) {
    Auth.clear();
    toast('Logged out successfully.', 'info');
    setTimeout(() => window.location.href = (base || '..') + '/index.html', 800);
  }
};

// ── API HELPER ────────────────────────────────────────────────
async function api(method, endpoint, body, auth) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth) headers['Authorization'] = 'Bearer ' + Auth.getToken();
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);
  const res  = await fetch(API + endpoint, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
}

// ── TOAST ─────────────────────────────────────────────────────
function toast(msg, type, duration) {
  type = type || 'info';
  duration = duration || 4000;
  let c = document.getElementById('toast-container');
  if (!c) { c = document.createElement('div'); c.id = 'toast-container'; document.body.appendChild(c); }
  const icons = { success: '✓', error: '✕', info: '→' };
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.innerHTML = '<span style="font-size:1rem">' + (icons[type]||'→') + '</span><span>' + msg + '</span>';
  c.appendChild(el);
  setTimeout(() => el.remove(), duration + 400);
}

// ── CHANGE PASSWORD MODAL ──────────────────────────────────────
function injectChangePasswordModal() {
  if (document.getElementById('cp-modal')) return;
  const modal = document.createElement('div');
  modal.id = 'cp-modal';
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal" style="max-width:420px">
      <div class="modal-head">
        <h2 class="modal-title">Change Password</h2>
        <button class="btn btn-ghost btn-sm" onclick="closeChangePassword()">✕</button>
      </div>
      <form id="cp-form">
        <div class="form-group">
          <label class="form-label">Current Password</label>
          <input type="password" id="cp-old" class="form-control" placeholder="Enter current password" required />
        </div>
        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" id="cp-new" class="form-control" placeholder="Min. 6 characters" required minlength="6" />
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input type="password" id="cp-confirm" class="form-control" placeholder="Repeat new password" required />
        </div>
        <div id="cp-error" style="color:#f87171;font-size:0.82rem;margin-bottom:0.75rem;display:none"></div>
        <div style="display:flex;gap:1rem">
          <button type="submit" class="btn btn-primary" style="flex:1" id="cp-btn">Update Password</button>
          <button type="button" class="btn btn-outline" onclick="closeChangePassword()">Cancel</button>
        </div>
      </form>
    </div>
  `;
  document.body.appendChild(modal);

  modal.addEventListener('click', (e) => { if (e.target === modal) closeChangePassword(); });

  document.getElementById('cp-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const oldPw  = document.getElementById('cp-old').value;
    const newPw  = document.getElementById('cp-new').value;
    const confPw = document.getElementById('cp-confirm').value;
    const errEl  = document.getElementById('cp-error');
    const btn    = document.getElementById('cp-btn');

    errEl.style.display = 'none';

    if (newPw !== confPw) {
      errEl.textContent = 'New passwords do not match.';
      errEl.style.display = 'block';
      return;
    }
    if (newPw === oldPw) {
      errEl.textContent = 'New password must be different from current password.';
      errEl.style.display = 'block';
      return;
    }

    btn.textContent = 'Updating…';
    btn.disabled = true;

    try {
      await api('PUT', '/auth/change-password', { old_password: oldPw, new_password: newPw }, true);
      toast('Password updated successfully!', 'success');
      closeChangePassword();
      document.getElementById('cp-form').reset();
    } catch (err) {
      errEl.textContent = err.message;
      errEl.style.display = 'block';
    } finally {
      btn.textContent = 'Update Password';
      btn.disabled = false;
    }
  });
}

function openChangePassword() {
  injectChangePasswordModal();
  document.getElementById('cp-modal').classList.add('open');
  // Close profile dropdown if open
  const dd = document.getElementById('profile-dropdown');
  if (dd) dd.style.display = 'none';
}

function closeChangePassword() {
  const m = document.getElementById('cp-modal');
  if (m) m.classList.remove('open');
}

// ── NAVBAR ────────────────────────────────────────────────────
function renderNavbar(activePage, base) {
  base = base || '..';
  const user    = Auth.getUser();
  const isAdmin = Auth.isAdmin();
  const navbar  = document.getElementById('navbar');
  if (!navbar) return;

  const profileMenu = user ? `
    <div style="position:relative">
      <button class="btn btn-outline btn-sm" id="profile-btn"
        onclick="toggleProfileMenu()" style="display:flex;align-items:center;gap:6px">
        <span style="width:24px;height:24px;border-radius:50%;background:var(--orange);
          display:inline-flex;align-items:center;justify-content:center;
          font-size:0.7rem;font-weight:700;color:#fff;flex-shrink:0">
          ${user.name.charAt(0).toUpperCase()}
        </span>
        ${user.name.split(' ')[0]}
        <span style="font-size:0.6rem;opacity:0.6">▼</span>
      </button>
      <div id="profile-dropdown" style="
        display:none;position:absolute;right:0;top:calc(100% + 8px);
        background:var(--bg-card);border:1px solid var(--border);
        border-radius:var(--radius);min-width:180px;z-index:2000;
        box-shadow:0 8px 32px rgba(0,0,0,0.4);overflow:hidden">
        <div style="padding:12px 16px;border-bottom:1px solid var(--border)">
          <div style="font-size:0.8rem;font-weight:600">${user.name}</div>
          <div style="font-size:0.72rem;color:var(--text-muted)">${user.email}</div>
          <div style="font-size:0.65rem;color:var(--orange);margin-top:2px;text-transform:uppercase;letter-spacing:0.05em">${user.role}</div>
        </div>
        <button onclick="openChangePassword()" style="
          display:flex;align-items:center;gap:8px;width:100%;padding:11px 16px;
          background:transparent;border:none;color:var(--text);font-family:'DM Sans',sans-serif;
          font-size:0.85rem;cursor:pointer;text-align:left;transition:background 0.15s">
          🔑 Change Password
        </button>
        <div style="height:1px;background:var(--border)"></div>
        <button onclick="Auth.logout('${base}')" style="
          display:flex;align-items:center;gap:8px;width:100%;padding:11px 16px;
          background:transparent;border:none;color:#f87171;font-family:'DM Sans',sans-serif;
          font-size:0.85rem;cursor:pointer;text-align:left;transition:background 0.15s">
          ↩ Logout
        </button>
      </div>
    </div>
  ` : `
    <a href="${base}/pages/login.html" class="btn btn-ghost btn-sm">Login</a>
    <a href="${base}/pages/register.html" class="btn btn-primary btn-sm">Get Started</a>
  `;

  navbar.innerHTML =
    '<a href="' + base + '/index.html" class="nav-logo">' +
      '<div class="logo-icon">' +
        '<svg viewBox="0 0 24 24"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.08 3.11H5.77L6.85 7zM19 17H5v-5h14v5z"/><circle cx="7.5" cy="14.5" r="1.5"/><circle cx="16.5" cy="14.5" r="1.5"/></svg>' +
      '</div>' +
      'Rent<span>Ride</span>' +
    '</a>' +
    '<nav class="nav-links" id="nav-links">' +
      '<a href="' + base + '/index.html" class="' + (activePage==='home'?'active':'') + '">Home</a>' +
      '<a href="' + base + '/pages/vehicles.html" class="' + (activePage==='vehicles'?'active':'') + '">Vehicles</a>' +
      (user ? '<a href="' + base + '/pages/bookings.html" class="' + (activePage==='bookings'?'active':'') + '">My Bookings</a>' : '') +
      (isAdmin ? '<a href="' + base + '/pages/admin.html" class="' + (activePage==='admin'?'active':'') + '">Admin</a>' : '') +
    '</nav>' +
    '<div class="nav-actions">' + profileMenu + '</div>' +
    '<div class="nav-hamburger" id="hamburger" onclick="toggleMobileMenu()"><span></span><span></span><span></span></div>';

  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    const dd = document.getElementById('profile-dropdown');
    const btn = document.getElementById('profile-btn');
    if (dd && btn && !btn.contains(e.target) && !dd.contains(e.target)) {
      dd.style.display = 'none';
    }
  });

  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 10);
  });
}

function toggleProfileMenu() {
  const dd = document.getElementById('profile-dropdown');
  if (dd) dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
}

function toggleMobileMenu() {
  const links = document.getElementById('nav-links');
  if (links) links.classList.toggle('mobile-open');
}

// ── FORMAT HELPERS ────────────────────────────────────────────
function formatDate(str) {
  if (!str) return '—';
  return new Date(str).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
}
function formatCurrency(n) {
  return '₹' + Number(n).toLocaleString('en-IN');
}
function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
}
function typeIcon(type) {
  const icons = { car:'🚗', bike:'🏍️', suv:'🚙', van:'🚐', truck:'🚛', scooter:'🛵' };
  return icons[type] || '🚗';
}
