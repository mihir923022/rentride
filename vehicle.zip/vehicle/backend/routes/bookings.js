const express = require('express');
const router = express.Router();
const { pool: db } = require('../config/db');
const { verifyToken, verifyAdmin } = require('../middleware/auth');

// Create booking
router.post('/', verifyToken, async (req, res) => {
  try {
    const { vehicle_id, start_date, end_date, pickup_location } = req.body;
    if (!vehicle_id || !start_date || !end_date)
      return res.status(400).json({ message: 'vehicle_id, start_date, end_date are required.' });

    const start = new Date(start_date);
    const end = new Date(end_date);
    if (end <= start)
      return res.status(400).json({ message: 'End date must be after start date.' });
    if (start < new Date(new Date().toDateString()))
      return res.status(400).json({ message: 'Start date cannot be in the past.' });

    const [vehicles] = await db.query('SELECT * FROM vehicles WHERE id = ? AND availability = 1', [vehicle_id]);
    if (!vehicles.length)
      return res.status(400).json({ message: 'Vehicle not available.' });

    const [overlap] = await db.query(
      `SELECT id FROM bookings WHERE vehicle_id = ? AND status != 'cancelled'
       AND NOT (end_date < ? OR start_date > ?)`,
      [vehicle_id, start_date, end_date]
    );
    if (overlap.length > 0)
      return res.status(409).json({ message: 'Vehicle already booked for these dates.' });

    const days = Math.ceil((end - start) / 86400000);
    const total_price = days * vehicles[0].price_per_day;
    const loc = pickup_location || vehicles[0].location;

    const [result] = await db.query(
      'INSERT INTO bookings (user_id, vehicle_id, start_date, end_date, total_price, status, pickup_location) VALUES (?,?,?,?,?,?,?)',
      [req.user.id, vehicle_id, start_date, end_date, total_price, 'confirmed', loc]
    );
    await db.query('UPDATE vehicles SET availability = 0 WHERE id = ?', [vehicle_id]);

    res.status(201).json({
      message: 'Booking confirmed!',
      booking: { id: result.insertId, total_price, days, status: 'confirmed' }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// Get current user's bookings
router.get('/my', verifyToken, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT b.*, v.name as vehicle_name, v.type as vehicle_type, v.image_url, v.brand
       FROM bookings b JOIN vehicles v ON b.vehicle_id = v.id
       WHERE b.user_id = ? ORDER BY b.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});

// Get all bookings — admin only
router.get('/all', verifyAdmin, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT b.*, v.name as vehicle_name, v.type as vehicle_type,
              u.name as user_name, u.email as user_email
       FROM bookings b
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN users u ON b.user_id = u.id
       ORDER BY b.created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});

// Admin dashboard stats
router.get('/stats', verifyAdmin, async (req, res) => {
  try {
    const [[{ total_bookings }]] = await db.query('SELECT COUNT(*) as total_bookings FROM bookings');
    const [[{ total_revenue }]] = await db.query("SELECT COALESCE(SUM(total_price),0) as total_revenue FROM bookings WHERE status != 'cancelled'");
    const [[{ total_users }]] = await db.query("SELECT COUNT(*) as total_users FROM users WHERE role = 'user'");
    const [[{ total_vehicles }]] = await db.query('SELECT COUNT(*) as total_vehicles FROM vehicles');
    const [[{ available_vehicles }]] = await db.query('SELECT COUNT(*) as available_vehicles FROM vehicles WHERE availability = 1');
    res.json({ total_bookings, total_revenue, total_users, total_vehicles, available_vehicles });
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});

// Cancel a booking (user)
router.put('/:id/cancel', verifyToken, async (req, res) => {
  try {
    const [bookings] = await db.query(
      'SELECT * FROM bookings WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );
    if (!bookings.length)
      return res.status(404).json({ message: 'Booking not found.' });
    if (bookings[0].status === 'cancelled')
      return res.status(400).json({ message: 'Already cancelled.' });

    await db.query("UPDATE bookings SET status = 'cancelled' WHERE id = ?", [req.params.id]);
    await db.query('UPDATE vehicles SET availability = 1 WHERE id = ?', [bookings[0].vehicle_id]);
    res.json({ message: 'Booking cancelled.' });
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});

// Update booking status — admin
router.put('/:id/status', verifyAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    const allowed = ['pending', 'confirmed', 'cancelled', 'completed'];
    if (!allowed.includes(status))
      return res.status(400).json({ message: 'Invalid status value.' });

    const [b] = await db.query('SELECT vehicle_id FROM bookings WHERE id = ?', [req.params.id]);
    if (!b.length) return res.status(404).json({ message: 'Booking not found.' });

    await db.query('UPDATE bookings SET status = ? WHERE id = ?', [status, req.params.id]);

    // confirmed → hide vehicle from listings (unavailable)
    if (status === 'confirmed') {
      await db.query('UPDATE vehicles SET availability = 0 WHERE id = ?', [b[0].vehicle_id]);
    }
    // cancelled or completed → free the vehicle back to listings
    if (status === 'cancelled' || status === 'completed') {
      await db.query('UPDATE vehicles SET availability = 1 WHERE id = ?', [b[0].vehicle_id]);
    }

    res.json({ message: 'Booking status updated to ' + status + '.' });
  } catch (err) {
    console.error('[status update]', err.message);
    res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;
