const express  = require('express');
const router   = express.Router();
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const { pool: db } = require('../config/db');

// ── REGISTER ────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password)
      return res.status(400).json({ message: 'All fields are required.' });

    if (password.length < 6)
      return res.status(400).json({ message: 'Password must be at least 6 characters.' });

    const [existing] = await db.query('SELECT id FROM users WHERE email = ?', [email.toLowerCase().trim()]);
    if (existing.length)
      return res.status(409).json({ message: 'Email already registered.' });

    const hashed = await bcrypt.hash(password, 10);
    const [result] = await db.query(
      "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')",
      [name.trim(), email.toLowerCase().trim(), hashed]
    );

    const token = jwt.sign(
      { id: result.insertId, name: name.trim(), email: email.toLowerCase().trim(), role: 'user' },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.status(201).json({
      message: 'Registered successfully.',
      token,
      user: { id: result.insertId, name: name.trim(), email: email.toLowerCase().trim(), role: 'user' }
    });
  } catch (err) {
    console.error('[register]', err.message);
    return res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

// ── LOGIN ───────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password)
      return res.status(400).json({ message: 'Email and password are required.' });

    // Normalize email — trim & lowercase to avoid mismatch
    const normalizedEmail = email.toLowerCase().trim();

    const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [normalizedEmail]);

    if (!rows.length)
      return res.status(401).json({ message: 'Invalid email or password.' });

    const user  = rows[0];
    const match = await bcrypt.compare(password, user.password);

    if (!match)
      return res.status(401).json({ message: 'Invalid email or password.' });

    const token = jwt.sign(
      { id: user.id, name: user.name, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.json({
      message: 'Login successful.',
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  } catch (err) {
    console.error('[login]', err.message);
    return res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

// ── CHANGE PASSWORD ──────────────────────────────────────────
router.put('/change-password', require('../middleware/auth').verifyToken, async (req, res) => {
  try {
    const { old_password, new_password } = req.body;

    if (!old_password || !new_password)
      return res.status(400).json({ message: 'Old password and new password are required.' });

    if (new_password.length < 6)
      return res.status(400).json({ message: 'New password must be at least 6 characters.' });

    if (old_password === new_password)
      return res.status(400).json({ message: 'New password must be different from old password.' });

    const [rows] = await db.query('SELECT password FROM users WHERE id = ?', [req.user.id]);
    if (!rows.length)
      return res.status(404).json({ message: 'User not found.' });

    const match = await bcrypt.compare(old_password, rows[0].password);
    if (!match)
      return res.status(401).json({ message: 'Old password is incorrect.' });

    const hashed = await bcrypt.hash(new_password, 10);
    await db.query('UPDATE users SET password = ? WHERE id = ?', [hashed, req.user.id]);

    return res.json({ message: 'Password changed successfully.' });
  } catch (err) {
    console.error('[change-password]', err.message);
    return res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

// ── GET CURRENT USER ─────────────────────────────────────────
router.get('/me', require('../middleware/auth').verifyToken, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id, name, email, role, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ message: 'User not found.' });
    return res.json(rows[0]);
  } catch (err) {
    return res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;
